<!DOCTYPE html>
<html>
  <head>
    <title>Ipheya-Manager</title>  
    <meta charset="utf-8">
    <meta name="viewport" content = "width=device-width, initial-scale=1, user-scalable=no">

    <link rel = "stylesheet" href = "../assets/bootstrap/css/bootstrap.min.css"/>
    <!-- <link rel = "stylesheet" href = "../assets/css/main.css" type = "text/css"/> -->
    <!-- <link rel = "stylesheet" href = "../assets/plugins/ionicons/css/ionicons.min.css" type = "text/css"/> -->
    <link rel = "stylesheet" href = "../assets/plugins/jquery-ui/jquery-ui.css" type = "text/css"/>
    <link rel = "icon" type = "image/png" href = "../assets/index/images/favicon.gif">
    <link rel = "stylesheet" href = "../assets/font-awesome/css/font-awesome.min.css" type = "text/css"/>
    <script src = "../assets/lib/jquery-2.1.3.min.js"></script>
    <script type = "text/javascript" src = "../assets/bootstrap/js/bootstrap.min.js"></script>
    <script type = "text/javascript" src = "../assets/plugins/jquery-ui/jquery-ui.js"></script>
    <script type = "text/javascript" src = "../assets/jquery/jquery-gmaps-latlon-picker.js"></script>
    <script type = "text/javascript" src = "../assets/lib/angular.min.js"></script>
    <link rel = "stylesheet" href = "../assets/plugins/datatables/dataTables.bootstrap.css" type = "text/css"/>
    <link ral = "stylesheet" href = "../assets/plugins/datatables/jquery.dataTables.css" type = "text/css"/>
    <script type = "text/javascript" src = "../assets/plugins/datatables/jquery.dataTables.js"></script>
    <script type = "text/javascript" src = "../assets/plugins/datatables/dataTables.bootstrap.js"></script>
    <link rel = "stylesheet" href = "../assets/Site.css" type = "text/css"/>
  </head>
  <body>
