<h2>Request Summary</h2><hr class="bhr"/>
<div class="col-lg-12">

            <div class="alert alert-info">
                <span class="glyphicon glyphicon-info-sign"></span> Select a service to view their details.
                <span class="glyphicon glyphicon-arrow-right"></span>
            </div>
            <u>Summary</u><br/><br/>
            Service : 2<br/>
            Maintanace : 5<br/>
            Repairs : 4 <br/>
            Survey : 1<br/>
            Total Request : 12<br/>
</div>