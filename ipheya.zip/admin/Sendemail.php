<?php
    mail('admin@gmail.com','Ticket Response','We have received your ticket, we will attend your matter as soon as possible');
    mail($to,$header,$message);
?>
