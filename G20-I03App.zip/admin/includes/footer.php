<footer class="text-center" style="width:100%" id="footer">
  &copy; Copyright <?php echo date('Y'); ?> Ipheya
</footer>

